/* --------------------------------------------------------------
Application 02 Template completion
Alexander Barrass 
5346980
---------------------------------------------------------------*/
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/adc.h" //Analog to Digital conversion
#include "math.h" //General math inclusion

#define LED_PIN GPIO_NUM_2  // Using GPIO2 for the LED
#define LDR_PIN GPIO_NUM_32
#define LDR_ADC_CHANNEL ADC1_CHANNEL_4
#define AVG_WINDOW 10
#define SENSOR_THRESHOLD 500

//Consider supressing the output
void led_task(void *pvParameters) {
    bool led_status = false;
    TickType_t currentTime = pdTICKS_TO_MS( xTaskGetTickCount() );

    while (1) {
        currentTime = pdTICKS_TO_MS( xTaskGetTickCount() );
        gpio_set_level(LED_PIN, 1);  //TODO: Set LED pin high or low based on led_status flag;
        led_status = !led_status;  //fixed by setting ! in
        printf("LED Cycle %s @ %lu\n", led_status ? "ON" : "OFF", currentTime);
        vTaskDelay(pdMS_TO_TICKS(500)); // Delay for 500 ms using MS to Ticks Function vs alternative which is MS / ticks per ms
       
    
    }
    vTaskDelete(NULL); // We'll never get here; tasks run forever
}

void print_status_task(void *pvParameters) {
    TickType_t currentTime = pdTICKS_TO_MS( xTaskGetTickCount() );
    TickType_t previousTime = 0;
    while (1) {
        previousTime = currentTime;
        currentTime = pdTICKS_TO_MS( xTaskGetTickCount() );
        
        // Prints a periodic message based on a thematic area. Output a timestamp (ms) and period (ms)
        printf("Containment maintained for %lums...\n",currentTime);
        vTaskDelay(pdMS_TO_TICKS(1000)); // Delay for 1000 ms
    }
    vTaskDelete(NULL); // We'll never get here; tasks run forever
}

//TODO11: Create new task for sensor reading every 500ms
void sensor_task(void *pvParameters) {
    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(LDR_ADC_CHANNEL, ADC_ATTEN_DB_11);

    // Variables to compute LUX
    int raw;
    float Vmeasure = 0.;
    float Rmeasure = 0.;
    float lux = 0.;
    // Variables for moving average
    int luxreadings[AVG_WINDOW] = {0};
    int idx = 0;
    float sum = 0;

    // Pre-fill the readings array with an initial sample to avoid startup anomaly
    for(int i = 0; i < AVG_WINDOW; ++i) {
        raw =  adc1_get_raw(LDR_ADC_CHANNEL);
        Vmeasure = 3.3f * (float)raw / 4095.0f; //TODO11b correct this with the equation seen earlier
        Rmeasure = 10000.0f * Vmeasure / (3.3f - Vmeasure); //TODO11c correct this with the equation seen earlier
        lux = 1000.0f * powf(Rmeasure/50.0f, -1.0f / 0.7f); //TODO11d correct this with the equation seen earlier
        luxreadings[i] = lux;
        sum += luxreadings[i];
    }

    const TickType_t periodTicks = pdMS_TO_TICKS(500); // e.g. 500 ms period
    TickType_t lastWakeTime = xTaskGetTickCount(); // initialize last wake time

    while (1) {
        // Read current sensor value
        raw = adc1_get_raw(LDR_ADC_CHANNEL);
        printf("**raw **: Sensor %d\n", raw);

        // Compute LUX
        Vmeasure = 3.3f * (float)raw / 4095.0f;
        Rmeasure = 10000.0f * Vmeasure / (3.3f - Vmeasure); 
        lux = 1000.0f * powf(Rmeasure/50.0f, -1.0f / 0.7f);
        sum -= luxreadings[idx]; 
        
        luxreadings[idx] = lux;        
        sum += lux;                 // add new value to sum
        idx = (idx + 1) % AVG_WINDOW;
        float avg = sum / AVG_WINDOW; // compute average

        //TODO11h Check threshold and print alert if exceeded or below based on context
        if (avg >= SENSOR_THRESHOLD) {
            printf("**Alert** LIGHT ANOMALY EXCEEDED VALUE %.2f! (Past: %d)\n", avg, SENSOR_THRESHOLD);
        } else {
        }
        vTaskDelayUntil(&lastWakeTime, periodTicks);

    }
}


void app_main() {
    // Initialize LED GPIO     
    gpio_reset_pin(LED_PIN);
    gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);
    // Initialize LDR PIN
    gpio_reset_pin(LDR_PIN);
    gpio_set_direction(LDR_PIN, GPIO_MODE_INPUT);

    adc1_config_width(ADC_WIDTH_BIT_12); //Resolution of 12 bits
    adc1_config_channel_atten(LDR_ADC_CHANNEL,ADC_ATTEN_DB_11); //Attenuation rate of 11dB

    xTaskCreatePinnedToCore(led_task, "LED", 2048, NULL, 2, NULL, 1);
    xTaskCreatePinnedToCore(print_status_task, "STATUS", 2048, NULL, 1, NULL, 1);
    xTaskCreatePinnedToCore(sensor_task, "SensorTask", 4096, NULL, 3, NULL, 1);
}
